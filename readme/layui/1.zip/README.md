# layui_doc-mirror


---

### Author：lehman
![](http://q1.qlogo.cn/g?b=qq&nk=280668200&s=100)

### Blog
[Lehman-Blog](https://www.lehman.top/)

### Genshin
<img alt="Genshin game card" src="https://genshin-card.getloli.com/detail/40/222323272.png" width="500">

---


#### 介绍

本站仅为layui文档镜像站点！

本站仅提供文档演示和下载！

本站也按作者要求去除了相应内容：

![备份 layui 在线文档的注意事项](https://images.gitee.com/uploads/images/2021/1012/214127_f3068c85_8718280.png "备份 layui 在线文档的注意事项.png")

#### 由来

2021年9月24日，发布官网停止维护后，第一时间就想备份整站文档。毕竟这个都用了这么多年了，习惯了。

![发布官网停止维护](https://images.gitee.com/uploads/images/2021/1012/214401_d62435af_8718280.png "发布官网停止维护.png")

