<?php

echo htmlspecialchars_decode($_POST['html']);

?>